package fr.ensim.tp2.tp5.model;

public class Main {
    private float temp;
    private float feels_like;
    private float temp_min;
    private float temp_max;
    private float pressure;
    private float humidity;


    public float getTemp() {
        return temp;
    }

    public float getFeels_like() {
        return feels_like;
    }


}