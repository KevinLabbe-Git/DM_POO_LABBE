package fr.ensim.tp2.tp5.model;

public class openWeatherClass {
    Main MainObject;

    public Main getMain() {
        return MainObject;
    }

    public void setMain(Main mainObject) {
        this.MainObject = mainObject;
    }

}