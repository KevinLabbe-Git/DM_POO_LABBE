package fr.ensim.tp2.tp5.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Features {
    ArrayList <Tools> features = new ArrayList <Tools> ();

    @Override
    public String toString() {
        return "Quote{" +
                "type='" + features.get(0).getType() + '\'' +
                ", value=" +  +
                '}';
    }

    public ArrayList <Tools> getFeatures() {
        return features;
    }

    public void setFeatures(ArrayList <Tools> features) {
        this.features = features;
    }
}