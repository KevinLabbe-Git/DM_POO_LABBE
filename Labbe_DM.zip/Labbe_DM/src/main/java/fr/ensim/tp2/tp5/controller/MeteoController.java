package fr.ensim.tp2.tp5.controller;

import fr.ensim.tp2.tp5.model.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
public class MeteoController {

    @GetMapping("/meteo")
    public String meteo(Model model) {
        return "meteo";
    }

    /*@PostMapping("/meteo")
    public String obtenirAdresse(@RequestParam("adr") String adresseRenseignee, Model model){
        return "form-adresse";
    }*/

    @PostMapping("/meteo")
    public String meteoPost(@RequestParam(name="adr") String adresse, Model model) {
        model.addAttribute("adr", adresse);

        RestTemplate restTemplate = new RestTemplate();
        String fooResourceUrl = "https://api-adresse.data.gouv.fr/search/?q=";
        Features response = restTemplate.getForObject(fooResourceUrl + adresse, Features.class);
        Tools tools = response.getFeatures().get(0);
        Position position = tools.getGeometry();
        Double lon = position.getCoordinates().get(0);
        Double lat = position.getCoordinates().get(1);

        RestTemplate rest = new RestTemplate();
        String url = "http://api.openweathermap.org/data/2.5/weather?lat="+lat+"&lon="+lon+"&units=metric&appid=434a28dd340e75797d7733e857068ad6";
        openWeatherClass reponse2 = rest.getForObject(url, openWeatherClass.class);
        Main main = reponse2.getMain();
        float temperature = main.getTemp();
        float ressenti = main.getFeels_like();

        model.addAttribute("temp", temperature);
        model.addAttribute("ress", ressenti);

        return "meteo";
    }
}
