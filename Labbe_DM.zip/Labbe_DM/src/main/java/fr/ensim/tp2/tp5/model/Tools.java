package fr.ensim.tp2.tp5.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Tools {
    private String type;
    Position positionObject;
    Type_Text typeTextObject;




    public String getType() {
        return type;
    }

    public Position getGeometry() {
        return positionObject;
    }

    public Type_Text getProperties() {
        return typeTextObject;
    }



    public void setType(String type) {
        this.type = type;
    }

    public void setGeometry(Position positionObject) {
        this.positionObject = positionObject;
    }

    public void setProperties(Type_Text typeTextObject) {
        this.typeTextObject = typeTextObject;
    }
}