package fr.ensim.tp2.tp5.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Type_Text {

    private String type;
    private String context;


    public String getType() {
        return type;
    }

    public String getContext() {
        return context;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setContext(String context) {
        this.context = context;
    }

}